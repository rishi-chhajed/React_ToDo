import React, {useState} from 'react';

function Bar() {
    const [name, setName] = useState('');

    function handleChange(event) {
        const { value } = event.target;
        setName(value);
    }

    function onFormSubmit(event) {
        //event.preventDefault();
        
        handleSubmit(name);
        setName('');
    }

    return (
        <form onSubmit={onFormSubmit}>
            <label for="name">ToDo</label>
            <input 
                type="text" 
                name="name" 
                id="name"
                value={name}
                onChange={handleChange} />
            <button type="submit">
                Submit
            </button>
        </form>
    );
    
}

export default Bar;