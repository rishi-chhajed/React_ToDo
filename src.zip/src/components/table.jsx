import React from 'react';

const TableBody = props => { 
    const rows = props.characterData.map((row, index) => {
        return (
            <tr key={index}>
                <td>{row.name}</td> 
                <td><button onClick={() => props.removeCharacterFunc(index)}>Done</button></td>
            </tr>
        );
    });

    return <tbody>{rows}</tbody>;
}

const Table = (props) => {
    const { characterData, removeCharacterFunc } = props;
        return (
            <table>
                <thead>
                    <tr>
                        <th>ToDo</th>
                    </tr>
                </thead>
                <TableBody characterData={characterData} removeCharacterFunc={removeCharacterFunc} />
            </table>
        );
}

export default Table;