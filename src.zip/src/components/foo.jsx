import React, { useState } from 'react';
import Table from './table';
import Bar from './bar';
import Navbar from './navbar';

function Foo() {
    const [characters, setCharacters] = useState([]);

    function removeCharacter(index){
        setCharacters(
            characters.filter((i) => { 
                return i !== index;
            })
        );
    }

    function handleSubmit(character){
        setCharacters([...characters, character]);
    }
        
    return (
        <div className="container">
            <Navbar/>
            <p>Add a TO-DO to the table.</p>
            <Table
                characterData = {characters}
                removeCharacterFunc = {removeCharacter}
            />
            <h3>Add New</h3>
            <Bar handleSubmit={handleSubmit} />
        </div>
    );
    
}

export default Foo;